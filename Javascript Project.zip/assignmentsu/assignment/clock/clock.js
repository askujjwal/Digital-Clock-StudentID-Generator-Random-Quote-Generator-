const timet = document.getElementById('time');
const datet = document.getElementById('date');
const stop = document.getElementById('stop');
const start = document.getElementById('start');
let date = new Date();
let time = `${date.getHours()}:${date.getMinutes()}:${date.getSeconds()}`;
timet.innerText = time;
let dateString = `${date.getDate()<10?'0'+date.getDate():date.getDate()}/${date.getMonth()<10?'0'+(date.getMonth()+1):date.getMonth+1}/${date.getFullYear()}`;
datet.innerText = dateString;
let interval;

function startTime(){
 
    interval = setInterval(()=>{
         date = new Date();
         time = `${date.getHours()}:${date.getMinutes()}:${date.getSeconds()}`;
        timet.innerText = time;
    },1000)

}
function stopTime(){
    clearInterval(interval);
}

stop.addEventListener('click',()=>{
    stopTime();
})
start.addEventListener('click',()=>{
    startTime();
})
startTime();

