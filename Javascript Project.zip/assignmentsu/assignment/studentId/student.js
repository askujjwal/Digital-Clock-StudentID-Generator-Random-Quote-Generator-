const btn = document.getElementById('btn');
const form = document.getElementById('form');
const detailpicture = document.getElementById('detailpicture');
const detailname = document.getElementById('detailstname');
const detaillocation = document.getElementById('detaillocation');
const detailcollege = document.getElementById('detailcollege');
const card = document.getElementById('detailcard');
card.style.visibility = 'hidden';
btn.addEventListener('click',(e)=>{
    e.preventDefault();
    card.style.visibility = 'visible';
    const [file] = form.elements.picture.files;
    detailpicture.src = URL.createObjectURL(file);
    URL.revokeObjectURL(file);
    console.log(form.elements.stname.value)
    detailname.innerText = form.elements.stname.value;
    detaillocation.innerText = form.elements.Location.value;
    detailcollege.innerText = form.elements.College.value;
})